//Dalton Cox

#include <iostream>
#include <iomanip>

using namespace std;

class Clock12 {
private:
    int hours;
    int minutes;
    int seconds;
    bool pm; // to indicate if it's PM or AM

public:
    // Constructor to initialize clock with given time
    Clock12(int h, int m, int s, bool isPM) : hours(h), minutes(m), seconds(s), pm(isPM) {}

    // Function to display 12-hour clock
    void display() {
        cout << "12-Hour Clock" << endl;
        cout << setw(2) << setfill('0') << hours << ":" << setw(2) << setfill('0') << minutes << ":" << setw(2) << setfill('0') << seconds << " ";
        if (pm)
            cout << "PM" << endl;
        else
            cout << "AM" << endl;
    }

    // Function to add one hour
    void addHour() {
        hours = (hours + 1) % 12;
        if (hours == 0) {
            hours = 12;
            pm = !pm; // Toggle between AM and PM when 12 is reached
        }
    }

    // Function to add one minute
    void addMinute() {
        minutes = (minutes + 1) % 60;
        if (minutes == 0)
            addHour(); // Increment hour when 60 minutes is reached
    }

    // Function to add one second
    void addSecond() {
        seconds = (seconds + 1) % 60;
        if (seconds == 0)
            addMinute(); // Increment minute when 60 seconds is reached
    }
};

class Clock24 {
private:
    int hours;
    int minutes;
    int seconds;

public:
    // Constructor to initialize clock with given time
    Clock24(int h, int m, int s) : hours(h), minutes(m), seconds(s) {}

    // Function to display 24-hour clock
    void display() {
        cout << "24-Hour Clock" << endl;
        cout << setw(2) << setfill('0') << hours << ":" << setw(2) << setfill('0') << minutes << ":" << setw(2) << setfill('0') << seconds << endl;
    }

    // Function to add one hour
    void addHour() {
        hours = (hours + 1) % 24;
    }

    // Function to add one minute
    void addMinute() {
        minutes = (minutes + 1) % 60;
        if (minutes == 0)
            addHour(); // Increment hour when 60 minutes is reached
    }

    // Function to add one second
    void addSecond() {
        seconds = (seconds + 1) % 60;
        if (seconds == 0)
            addMinute(); // Increment minute when 60 seconds is reached
    }
};

class Menu {
public:
    static void displayMenu() {
        cout << "****" << endl;
        cout << "* 1 - Add One Hour" << endl;
        cout << "* 2 - Add One Minute" << endl;
        cout << "* 3 - Add One Second" << endl;
        cout << "* 4 - Exit Program" << endl;
    }

    static int getUserChoice() {
        int choice;
        cout << "Enter your choice: ";
        cin >> choice;
        return choice;
    }
};

int main() {
    // Initialize clocks
    Clock12 clock12(12, 0, 0, false); // 12:00:00 AM
    Clock24 clock24(0, 0, 0); // 00:00:00

    int choice;
    do {
        // Display clocks
        clock12.display();
        cout << endl;
        clock24.display();
        cout << endl;

        // Display menu and get user choice
        Menu::displayMenu();
        choice = Menu::getUserChoice();

        // Perform action based on user choice
        switch (choice) {
        case 1: // Add One Hour
            clock12.addHour();
            clock24.addHour();
            break;
        case 2: // Add One Minute
            clock12.addMinute();
            clock24.addMinute();
            break;
        case 3: // Add One Second
            clock12.addSecond();
            clock24.addSecond();
            break;
        case 4: // Exit Program
            cout << "Exiting program..." << endl;
            break;
        default:
            cout << "Invalid choice! Please enter a valid option." << endl;
        }
    } while (choice != 4);

    return 0;
}
